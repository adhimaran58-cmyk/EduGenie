import os

os.environ["USE_MOCK_AI"] = "true"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["ai_mode"] == "mock"


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text


def test_qa():
    response = client.post("/api/qa", json={"text": "What is the largest ocean?"})
    assert response.status_code == 200
    assert response.json()["result"]


def test_explain():
    response = client.post("/api/explain", json={"text": "Explain photosynthesis."})
    assert response.status_code == 200
    assert response.json()["result"]


def test_quiz():
    response = client.post("/api/quiz", json={"text": "Photosynthesis converts light energy into chemical energy."})
    assert response.status_code == 200
    body = response.json()
    assert len(body["questions"]) == 3
    assert all(len(q["options"]) == 4 for q in body["questions"])


def test_summary():
    response = client.post("/api/summarize", json={"text": "A short educational passage."})
    assert response.status_code == 200
    assert response.json()["result"]


def test_learning_path():
    response = client.post("/api/learn/recommendations", json={"text": "SQL"})
    assert response.status_code == 200
    body = response.json()
    assert body["topic"] == "SQL"
    assert len(body["steps"]) >= 1


def test_empty_text_is_rejected():
    response = client.post("/api/qa", json={"text": "   "})
    assert response.status_code == 422
