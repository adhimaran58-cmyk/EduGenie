const state = {
  task: "qa",
};

const taskConfig = {
  qa: {
    title: "Ask EduGenie",
    help: "Ask a question and get a concise educational answer.",
    placeholder: "Example: Which is the largest ocean on Earth?",
    button: "Ask EduGenie",
    endpoint: "/api/qa",
  },
  explain: {
    title: "Explain a Concept",
    help: "Turn a complex topic into a beginner-friendly explanation.",
    placeholder: "Example: Explain the Pythagorean theorem to a beginner.",
    button: "Explain",
    endpoint: "/api/explain",
  },
  quiz: {
    title: "Generate a Quiz",
    help: "Create three MCQs with four options from your topic or passage.",
    placeholder: "Paste a lesson or passage here...",
    button: "Generate Quiz",
    endpoint: "/api/quiz",
  },
  summarize: {
    title: "Summarize Text",
    help: "Condense a long educational passage while preserving key ideas.",
    placeholder: "Paste the passage you want to summarize...",
    button: "Summarize",
    endpoint: "/api/summarize",
  },
  learn: {
    title: "Build a Learning Path",
    help: "Get a structured beginner-to-advanced plan for a topic.",
    placeholder: "Example: I want to learn SQL from beginner to advanced.",
    button: "Build Path",
    endpoint: "/api/learn/recommendations",
  },
};

const tabs = document.querySelectorAll(".task-tab");
const input = document.querySelector("#input-text");
const title = document.querySelector("#task-title");
const help = document.querySelector("#task-help");
const submit = document.querySelector("#submit-btn");
const clear = document.querySelector("#clear-btn");
const result = document.querySelector("#result");
const loading = document.querySelector("#loading");
const error = document.querySelector("#error-message");
const statusPill = document.querySelector("#status-pill");

function setTask(task) {
  state.task = task;
  const config = taskConfig[task];
  title.textContent = config.title;
  help.textContent = config.help;
  input.placeholder = config.placeholder;
  submit.textContent = config.button;
  tabs.forEach(tab => tab.classList.toggle("active", tab.dataset.task === task));
  error.hidden = true;
}

tabs.forEach(tab => tab.addEventListener("click", () => setTask(tab.dataset.task)));

clear.addEventListener("click", () => {
  input.value = "";
  result.innerHTML = '<p class="muted">Your result will appear here.</p>';
  error.hidden = true;
});

async function checkHealth() {
  try {
    const response = await fetch("/health");
    const data = await response.json();
    statusPill.textContent = data.ai_mode === "mock"
      ? "API online • Mock AI"
      : `API online • ${data.model}`;
  } catch {
    statusPill.textContent = "API unavailable";
  }
}

function renderText(data) {
  const text = document.createElement("div");
  text.textContent = data.result;
  result.replaceChildren(text);
}

function renderQuiz(data) {
  result.innerHTML = "";
  const heading = document.createElement("h3");
  heading.textContent = data.title;
  result.appendChild(heading);

  data.questions.forEach((question, index) => {
    const box = document.createElement("div");
    box.className = "quiz-question";

    const q = document.createElement("h3");
    q.textContent = `${index + 1}. ${question.question}`;
    box.appendChild(q);

    const feedback = document.createElement("p");
    feedback.className = "quiz-feedback";

    question.options.forEach(option => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "quiz-option";
      button.textContent = option;

      button.addEventListener("click", () => {
        box.querySelectorAll(".quiz-option").forEach(b => {
          b.disabled = true;
          if (b.textContent === question.correct_answer) {
            b.classList.add("correct");
          }
        });

        if (option === question.correct_answer) {
          feedback.textContent = "Correct! " + question.explanation;
        } else {
          button.classList.add("incorrect");
          feedback.textContent =
            `Not quite. Correct answer: ${question.correct_answer}. ${question.explanation}`;
        }
      });

      box.appendChild(button);
    });

    box.appendChild(feedback);
    result.appendChild(box);
  });
}

function renderLearningPath(data) {
  result.innerHTML = "";

  const overview = document.createElement("p");
  overview.textContent = data.overview;
  result.appendChild(overview);

  data.steps.forEach(step => {
    const section = document.createElement("section");
    section.className = "path-step";

    const h = document.createElement("h3");
    h.textContent = `${step.level} • ${step.suggested_duration}`;
    section.appendChild(h);

    const topics = document.createElement("ul");
    step.topics.forEach(topic => {
      const li = document.createElement("li");
      li.textContent = topic;
      topics.appendChild(li);
    });
    section.appendChild(topics);

    const resources = document.createElement("p");
    resources.textContent = `Resources: ${step.resources.join(", ")}`;
    section.appendChild(resources);

    result.appendChild(section);
  });

  if (data.study_tips?.length) {
    const tips = document.createElement("p");
    tips.textContent = `Study tips: ${data.study_tips.join(" • ")}`;
    result.appendChild(tips);
  }
}

submit.addEventListener("click", async () => {
  const text = input.value.trim();
  error.hidden = true;

  if (!text) {
    error.textContent = "Please enter a question, topic, or passage.";
    error.hidden = false;
    return;
  }

  const config = taskConfig[state.task];
  submit.disabled = true;
  loading.hidden = false;
  result.innerHTML = '<p class="muted">Generating your result…</p>';

  try {
    const response = await fetch(config.endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "The server returned an error.");
    }

    if (state.task === "quiz") renderQuiz(data);
    else if (state.task === "learn") renderLearningPath(data);
    else renderText(data);
  } catch (err) {
    error.textContent = err.message || "Something went wrong.";
    error.hidden = false;
    result.innerHTML = '<p class="muted">No result generated.</p>';
  } finally {
    submit.disabled = false;
    loading.hidden = true;
  }
});

checkHealth();
