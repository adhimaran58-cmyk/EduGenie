from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import get_settings
from app.schemas import (
    TextRequest,
    TextResponse,
    QuizResponse,
    LearningPathResponse,
)
from app.services.qna import answer_question
from app.services.explanation import explain_concept
from app.services.quiz import generate_quiz
from app.services.summary import summarize_text
from app.services.learning_path import get_learning_recommendations

settings = get_settings()
BASE_DIR = Path(__file__).resolve().parent.parent

app = FastAPI(
    title="EduGenie API",
    description="Google Gemini powered educational learning assistant.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"app_name": settings.app_name},
    )


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "app": settings.app_name,
        "ai_mode": "mock" if settings.use_mock_ai else "gemini",
        "local_explainer": settings.use_local_explainer,
        "model": settings.gemini_model,
    }


def _check_length(text: str) -> None:
    if len(text) > settings.max_input_chars:
        raise HTTPException(
            status_code=413,
            detail=f"Input exceeds the {settings.max_input_chars} character limit.",
        )


def _run_ai(operation):
    try:
        return operation()
    except HTTPException:
        raise
    except Exception as exc:
        # Keep internal details out of normal production responses.
        raise HTTPException(
            status_code=502,
            detail=f"AI operation failed: {exc}",
        ) from exc


@app.post("/api/qa", response_model=TextResponse)
async def qa(request: TextRequest):
    _check_length(request.text)
    return TextResponse(result=_run_ai(lambda: answer_question(request.text)))


@app.post("/api/explain", response_model=TextResponse)
async def explain(request: TextRequest):
    _check_length(request.text)
    return TextResponse(result=_run_ai(lambda: explain_concept(request.text)))


@app.post("/api/quiz", response_model=QuizResponse)
async def quiz(request: TextRequest):
    _check_length(request.text)
    return _run_ai(lambda: generate_quiz(request.text))


@app.post("/api/summarize", response_model=TextResponse)
async def summarize(request: TextRequest):
    _check_length(request.text)
    return TextResponse(result=_run_ai(lambda: summarize_text(request.text)))


@app.post("/api/learn/recommendations", response_model=LearningPathResponse)
async def learn(request: TextRequest):
    _check_length(request.text)
    return _run_ai(lambda: get_learning_recommendations(request.text))
