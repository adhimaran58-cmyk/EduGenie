from __future__ import annotations

from typing import TypeVar, Type
from pydantic import BaseModel
from app.config import get_settings

T = TypeVar("T", bound=BaseModel)


class GeminiService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self._client = None

    @property
    def client(self):
        if self._client is None:
            if self.settings.use_mock_ai:
                return None
            if not self.settings.gemini_api_key:
                raise RuntimeError(
                    "GEMINI_API_KEY is not configured. Add it to .env or enable USE_MOCK_AI."
                )
            from google import genai
            self._client = genai.Client(api_key=self.settings.gemini_api_key)
        return self._client

    def generate_text(self, prompt: str) -> str:
        if self.settings.use_mock_ai:
            return self._mock_text(prompt)

        from google.genai import types
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=2048,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()

    def generate_structured(self, prompt: str, schema: Type[T]) -> T:
        if self.settings.use_mock_ai:
            return self._mock_structured(schema)

        from google.genai import types
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=4096,
                response_mime_type="application/json",
                response_schema=schema,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty structured response.")
        return schema.model_validate_json(text)

    def _mock_text(self, prompt: str) -> str:
        lower = prompt.lower()
        if "largest ocean" in lower:
            return "The Pacific Ocean is the largest ocean on Earth."
        if "summar" in lower:
            return "This is a mock summary used for local testing. Real Gemini mode will summarize the supplied passage."
        if "explain" in lower:
            return "This is a mock explanation used for testing. Real Gemini mode will explain the requested concept in simple language."
        if "learning path" in lower:
            return "This is a mock learning path used for testing. Real Gemini mode will create a beginner-to-advanced study plan."
        return "Mock AI response. Configure GEMINI_API_KEY and set USE_MOCK_AI=false for real Gemini responses."

    def _mock_structured(self, schema: Type[T]) -> T:
        from app.schemas import QuizResponse, LearningPathResponse, LearningStep, QuizQuestion

        if schema is QuizResponse:
            return QuizResponse(
                title="Practice Quiz",
                questions=[
                    QuizQuestion(
                        question="Which option is a mock answer?",
                        options=["A", "B", "C", "D"],
                        correct_answer="A",
                        explanation="A is the mock correct answer.",
                    ),
                    QuizQuestion(
                        question="Why is this quiz available?",
                        options=["Testing", "Weather", "Music", "Travel"],
                        correct_answer="Testing",
                        explanation="It allows the API to be tested without a live model.",
                    ),
                    QuizQuestion(
                        question="What should you configure for real AI?",
                        options=["GEMINI_API_KEY", "SCREEN_SIZE", "PRINTER", "BLUETOOTH"],
                        correct_answer="GEMINI_API_KEY",
                        explanation="The server needs a valid Gemini API key.",
                    ),
                ],
            )

        if schema is LearningPathResponse:
            return LearningPathResponse(
                topic="Requested topic",
                overview="Mock learning path for local API testing.",
                steps=[
                    LearningStep(
                        level="Beginner",
                        topics=["Core vocabulary", "Basic concepts"],
                        suggested_duration="1 week",
                        resources=["Official documentation"],
                    ),
                    LearningStep(
                        level="Intermediate",
                        topics=["Practice", "Small projects"],
                        suggested_duration="2 weeks",
                        resources=["Tutorials", "Practice exercises"],
                    ),
                    LearningStep(
                        level="Advanced",
                        topics=["Architecture", "Real-world projects"],
                        suggested_duration="3 weeks",
                        resources=["Advanced documentation", "Projects"],
                    ),
                ],
                study_tips=["Practice consistently", "Build small projects"],
            )

        raise RuntimeError(f"No mock schema implementation for {schema.__name__}.")


gemini_service = GeminiService()
