from __future__ import annotations

from functools import lru_cache


MODEL_NAME = "MBZUAI/LaMini-Flan-T5-783M"


@lru_cache(maxsize=1)
def _load_model():
    try:
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
        import torch
    except ImportError as exc:
        raise RuntimeError(
            "Local explainer dependencies are missing. Install requirements-local.txt."
        ) from exc

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)
    model.eval()
    return tokenizer, model, torch


def explain_locally(topic: str) -> str:
    tokenizer, model, torch = _load_model()
    prompt = (
        "Explain the following educational topic to a beginner. "
        "Use simple language, short paragraphs, and one example if useful. "
        f"Topic: {topic}"
    )
    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=512,
    )
    with torch.inference_mode():
        output = model.generate(
            **inputs,
            max_new_tokens=220,
            num_beams=4,
            early_stopping=True,
        )
    return tokenizer.decode(output[0], skip_special_tokens=True).strip()
