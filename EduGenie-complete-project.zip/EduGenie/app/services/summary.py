from app.ai.gemini import gemini_service


def summarize_text(source_text: str) -> str:
    prompt = f"""
Summarize the following educational passage for a student.
Preserve the important facts and relationships.
Use simple language and short bullet points where useful.
Do not add facts that are absent from the passage.

Passage:
{source_text}
"""
    return gemini_service.generate_text(prompt)
