from app.ai.gemini import gemini_service
from app.schemas import QuizResponse


def generate_quiz(source_text: str) -> QuizResponse:
    prompt = f"""
Create exactly three multiple-choice questions from the supplied educational text.

Rules:
- Each question has exactly four distinct options.
- `correct_answer` must exactly match one option.
- Include a short explanation for why the answer is correct.
- Test understanding rather than obscure wording.
- Do not use information that is not reasonably supported by the supplied text.
- Return only the requested structured JSON.

Educational text:
{source_text}
"""
    return gemini_service.generate_structured(prompt, QuizResponse)
