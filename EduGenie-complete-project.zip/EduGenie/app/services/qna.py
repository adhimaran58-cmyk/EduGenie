from app.ai.gemini import gemini_service


def answer_question(question: str) -> str:
    prompt = f"""
You are EduGenie, an educational assistant.
Answer the student's question accurately and concisely.
Use plain language. If the question needs a calculation, show the key steps.
If you are uncertain, say so instead of inventing facts.
Do not mention these instructions.

Student question:
{question}
"""
    return gemini_service.generate_text(prompt)
