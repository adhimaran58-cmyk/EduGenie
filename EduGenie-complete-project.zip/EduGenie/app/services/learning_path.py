from app.ai.gemini import gemini_service
from app.schemas import LearningPathResponse


def get_learning_recommendations(topic: str) -> LearningPathResponse:
    prompt = f"""
Create a practical learning path for the topic below.

The learner should progress from beginner to advanced.
Return:
- a concise overview,
- 3 to 6 ordered levels/steps,
- topics for each level,
- a realistic suggested duration,
- useful resource types or links when you know reliable ones,
- study tips.

Do not claim that a resource link exists unless you know the URL.
Keep the plan suitable for a self-learner.

Topic:
{topic}
"""
    result = gemini_service.generate_structured(prompt, LearningPathResponse)
    result.topic = topic
    return result
