from app.ai.gemini import gemini_service
from app.ai.local_explainer import explain_locally
from app.config import get_settings


def explain_concept(topic: str) -> str:
    settings = get_settings()

    if settings.use_local_explainer:
        return explain_locally(topic)

    prompt = f"""
Explain this educational concept to a beginner.
Requirements:
- Start with a one-sentence definition.
- Break the idea into 3 to 5 simple points.
- Include a short real-world or practical example.
- Avoid unnecessary jargon.
- Keep the answer under about 350 words.

Concept:
{topic}
"""
    return gemini_service.generate_text(prompt)
