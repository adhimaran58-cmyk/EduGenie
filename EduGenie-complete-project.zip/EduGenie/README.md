# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant based on the supplied project documentation.

## Features

- Question answering
- Simple concept explanations
- 3-question MCQ quiz generation
- Long-text summarization
- Personalized beginner-to-advanced learning paths
- Quiz answer checking in the browser
- FastAPI REST API
- Responsive HTML/CSS/JavaScript frontend
- Optional local `LaMini-Flan-T5-783M` explainer
- Mock AI mode for testing without an API key

## Architecture

```text
EduGenie/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── schemas.py
│   ├── ai/
│   │   ├── __init__.py
│   │   ├── gemini.py
│   │   └── local_explainer.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── qna.py
│   │   ├── explanation.py
│   │   ├── quiz.py
│   │   ├── summary.py
│   │   └── learning_path.py
│   └── main.py
├── tests/
│   ├── __init__.py
│   └── test_api.py
├── static/
│   ├── app.js
│   └── style.css
├── templates/
│   └── index.html
├── .env.example
├── .gitignore
├── requirements.txt
├── requirements-local.txt
└── run.py
```

## 1. Prerequisites

- Python 3.10 or newer
- VS Code
- Internet access for Gemini API calls
- A Google Gemini API key for real AI mode

The local LaMini explainer is optional and is not required for the rest of the application.

## 2. Create the environment

### Windows PowerShell

```powershell
cd EduGenie
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then activate again.

### macOS / Linux

```bash
cd EduGenie
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Configure Gemini

Copy `.env.example` to `.env`.

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
USE_MOCK_AI=false
USE_LOCAL_EXPLAINER=false
```

`GEMINI_MODEL` is configurable so the application can be moved to a newer supported Gemini model without changing Python code.

For a no-key smoke test, set:

```text
USE_MOCK_AI=true
```

Never commit `.env`.

## 4. Optional local LaMini explainer

The supplied documentation specifies `LaMini-Flan-T5-783M` for concept explanation. To enable that implementation:

```bash
pip install -r requirements-local.txt
```

Then set:

```text
USE_LOCAL_EXPLAINER=true
```

The model is downloaded lazily the first time `/api/explain` is used. On a CPU-only machine this can take time and use significant memory. If disabled, explanation uses Gemini instead.

## 5. Run

```bash
python run.py
```

Or:

```bash
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

## 6. API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Web application |
| GET | `/health` | Health/config status |
| POST | `/api/qa` | Answer a question |
| POST | `/api/explain` | Explain a concept |
| POST | `/api/quiz` | Generate 3 MCQs |
| POST | `/api/summarize` | Summarize text |
| POST | `/api/learn/recommendations` | Generate learning path |

All AI request bodies use:

```json
{
  "text": "Your question, topic, or passage"
}
```

Quiz example:

```json
{
  "text": "The Pythagorean theorem states that for a right triangle..."
}
```

## 7. Test

Run:

```bash
pytest -q
```

The tests run in mock mode and do not require a Gemini key.

## 8. Example curl requests

```bash
curl http://127.0.0.1:8000/health
```

```bash
curl -X POST http://127.0.0.1:8000/api/qa \
  -H "Content-Type: application/json" \
  -d "{\"text\":\"What is the largest ocean on Earth?\"}"
```

## Troubleshooting

### `GEMINI_API_KEY is missing`

Set `GEMINI_API_KEY` in `.env`, or use `USE_MOCK_AI=true` for local testing.

### API returns 429/403

Check the API key, quota, model availability, and Google AI Studio/API project configuration. You can change `GEMINI_MODEL` without changing the rest of the application.

### Local explanation is slow

This is expected on CPU because LaMini-Flan-T5 is a transformer model. Set `USE_LOCAL_EXPLAINER=false` to use Gemini for explanations.

### Port already in use

```bash
uvicorn app.main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

## Security notes

- The Gemini key is server-side only.
- `.env` is ignored by Git.
- User input is length-limited by Pydantic.
- The frontend uses `textContent` rather than injecting AI output as HTML.
- CORS is restricted by configuration instead of allowing every origin by default.
